#!/bin/sh

rm -rf /koolshare/dynv6
rm -rf /koolshare/scripts/dynv6_config.sh
rm -rf /koolshare/webs/Module_dynv6.asp
rm -rf /koolshare/res/icon-dynv6.png
rm -rf /koolshare/res/md5.js
rm -rf /koolshare/res/rsa.js
rm -rf /koolshare/res/sha1.js
rm -rf /koolshare/scripts/dynv6_config.sh
rm -rf /koolshare/init.d/S99dynv6.sh
